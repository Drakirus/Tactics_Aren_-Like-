Tactics Arena Like  [![Build Status](https://travis-ci.org/Drakirus/Tactics_Arena_Like.svg?branch=master)](https://travis-ci.org/Drakirus/Tactics_Arena_Like/branches)
==

Notre projet, qui se déroule dans le cadre de notre premier semestre de deuxième année de licence SPI, a pour but de nous faire programmer en langage C une version, fonctionnelle sur la console et qui nous est propre, de ce jeu. Notre trinôme se compose de **Champion Pierre, Laville Martin et Mok Modira**.

# Implementation LUA
## Add IA vs IA

Maintenant le joueur à l'option de jouer avec une IA qu'il aura codé (dans le langage LUA)

